const mongoose = require('mongoose');

const UserSchema = mongoose.Schema({
    userID:Int16Array,
    firstName: String,
    lastName: String,
    phone:String,
    email:String,
    address ,
        addressLine:String,
        city:String,
        state:String,
        zipCode:String,
 
    encryptedPassword:String,
    isDeleted:String
   
  

} 
);

module.exports = mongoose.model('user', UserSchema);